import React, { Component } from "react";
import ErrorBound from "./ErrorBound";
import Refs from "./Refs";
import UseEffectDemo from './hooks/useEffectDemo'
import UseContext from './hooks/UseContext'
import UseReducer from './hooks/UseReducer'
// import {commonContext,light} from './hooks/commonContext'
import * as commonTheme from './hooks/commonContext'
const ThemeContext = React.createContext("green");
const ThemeSizeContext = React.createContext("32");
console.log(ThemeContext);

class App extends React.Component {
 constructor(props){
   super(props);
   this.state={
     isTrue:true
   }
 }
 test=()=>{
   this.setState({
     isTrue:false
   })
 }
  render() {
    // 使用一个 Provider 来将当前的 theme 传递给以下的组件树。
    // 无论多深，任何组件都能读取这个值。
    // 在这个例子中，我们将 “dark” 作为当前的值传递下去。
    const isTrue = this.state.isTrue;
    return (
  <div>
    <commonTheme.commonContext.Provider value={commonTheme.light}>
      {
      isTrue?<UseEffectDemo/>:<div>test</div>
      }
      <button onClick={this.test}>test</button>
      <UseContext/>
      <UseReducer/>
      </commonTheme.commonContext.Provider>
  </div>
      // <ErrorBound>
      //   <ThemeContext.Provider value="red">
      //     <Refs />
      //     <ThemeSizeContext.Provider value="24">
      //       <Toolbar />
      //     </ThemeSizeContext.Provider>
      //   </ThemeContext.Provider>
      // </ErrorBound>
    );
  }
}

// 中间的组件再也不必指明往下传递 theme 了。
function Toolbar() {
  return (
    <div>
      <ThemedButton />
    </div>
  );
}

class ThemedButton extends React.Component {
  // 指定 contextType 读取当前的 theme context。
  // React 会往上找到最近的 theme Provider，然后使用它的值。
  // 在这个例子中，当前的 theme 值为 “dark”。
  // static contextType = ThemeContext;
  compontentDidMount() {
    throw new Error("I crashed!");
  }
  render() {
    return (
      // <ThemeContext.Consumer>
      //   {(color) => {
      //     console.log(color);
      //     return (
      //       <ThemeSizeContext.Consumer>
      //         {(value) => {
      //           console.log(value);
      //           return <div style={{ color: color, fontSize: value + "px" }}>ghfghfgh</div>;
      //         }}
      //       </ThemeSizeContext.Consumer>
      //     );
      //   }}
      // </ThemeContext.Consumer>
      <UseEffectDemo/>
    );
  }
}

export default App;
